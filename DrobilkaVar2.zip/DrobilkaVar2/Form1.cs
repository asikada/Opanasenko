﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DrobilkaVar2
{
    public partial class Form1 : Form
    {
        SqlConnection con;
        DataSet data;
        SqlDataAdapter sda;
        SqlCommandBuilder cmd;
        string cs;
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Schet schet = new Schet();
            schet.ShowDialog();
        }

        private void btnComp_Click(object sender, EventArgs e)
        {
            Company company = new Company();    
            company.ShowDialog();
        }

        private void btnEx_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnAll_Click(object sender, EventArgs e)
        {
            cs = "Data Source = DESKTOP-R3MDFKQ\\SQLEXPRESS; Initial Catalog = Drobilka; Integrated Security = SSPI";
            con = new SqlConnection(cs);
            data = new DataSet();
            sda = new SqlDataAdapter("SELECT * FROM  Schet, Company WHERE Schet.CompanyId = Company.Id", con);
            cmd = new SqlCommandBuilder(sda);
            sda.Fill(data, "company");
            dataGridView1.DataSource = data.Tables["company"];
            sda.Update(data, "company");
        }
    }
}
