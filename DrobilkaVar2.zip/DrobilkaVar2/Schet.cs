﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DrobilkaVar2
{
    public partial class Schet : Form
    {
        SqlConnection con;
        DataSet data;
        SqlDataAdapter sda;
        SqlCommandBuilder cmd;
        string cs;
        public Schet()
        {
            InitializeComponent();
            cs = "Data Source = DESKTOP-R3MDFKQ\\SQLEXPRESS; Initial Catalog = Drobilka; Integrated Security = SSPI";
            con = new SqlConnection(cs);
            data = new DataSet();
            sda = new SqlDataAdapter("SELECT * FROM Schet", con);
            cmd = new SqlCommandBuilder(sda);
            sda.Fill(data, "schet");
            dtGridView1.DataSource = data.Tables["schet"];
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            sda.Update(data, "schet");
        }
    }
}
