﻿namespace DrobilkaVar2
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.btnEx = new System.Windows.Forms.Button();
            this.btnComp = new System.Windows.Forms.Button();
            this.btnSchet = new System.Windows.Forms.Button();
            this.btnAll = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.btnEx, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.btnComp, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.btnSchet, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnAll, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 12);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(193, 405);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // btnEx
            // 
            this.btnEx.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnEx.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnEx.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnEx.Location = new System.Drawing.Point(10, 313);
            this.btnEx.Margin = new System.Windows.Forms.Padding(10);
            this.btnEx.Name = "btnEx";
            this.btnEx.Size = new System.Drawing.Size(173, 82);
            this.btnEx.TabIndex = 3;
            this.btnEx.Text = "Выход";
            this.btnEx.UseVisualStyleBackColor = false;
            this.btnEx.Click += new System.EventHandler(this.btnEx_Click);
            // 
            // btnComp
            // 
            this.btnComp.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnComp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnComp.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnComp.Location = new System.Drawing.Point(10, 212);
            this.btnComp.Margin = new System.Windows.Forms.Padding(10);
            this.btnComp.Name = "btnComp";
            this.btnComp.Size = new System.Drawing.Size(173, 81);
            this.btnComp.TabIndex = 2;
            this.btnComp.Text = "Добавить новую компанию";
            this.btnComp.UseVisualStyleBackColor = false;
            this.btnComp.Click += new System.EventHandler(this.btnComp_Click);
            // 
            // btnSchet
            // 
            this.btnSchet.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnSchet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnSchet.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnSchet.Location = new System.Drawing.Point(10, 111);
            this.btnSchet.Margin = new System.Windows.Forms.Padding(10);
            this.btnSchet.Name = "btnSchet";
            this.btnSchet.Size = new System.Drawing.Size(173, 81);
            this.btnSchet.TabIndex = 1;
            this.btnSchet.Text = "Добавить новый счет";
            this.btnSchet.UseVisualStyleBackColor = false;
            this.btnSchet.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnAll
            // 
            this.btnAll.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnAll.Location = new System.Drawing.Point(10, 10);
            this.btnAll.Margin = new System.Windows.Forms.Padding(10);
            this.btnAll.Name = "btnAll";
            this.btnAll.Size = new System.Drawing.Size(173, 81);
            this.btnAll.TabIndex = 0;
            this.btnAll.Text = "Вывести все счета ";
            this.btnAll.UseVisualStyleBackColor = false;
            this.btnAll.Click += new System.EventHandler(this.btnAll_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(226, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(523, 405);
            this.dataGridView1.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(761, 433);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button btnEx;
        private System.Windows.Forms.Button btnComp;
        private System.Windows.Forms.Button btnSchet;
        private System.Windows.Forms.Button btnAll;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}

